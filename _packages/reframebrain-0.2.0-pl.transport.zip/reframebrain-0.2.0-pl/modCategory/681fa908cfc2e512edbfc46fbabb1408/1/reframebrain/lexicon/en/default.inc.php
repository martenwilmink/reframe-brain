<?php

// Map
// =====================================================================

$_lang['reframebrain.map.button_read_more'] = "More info";
$_lang['reframebrain.map.location_obfuscated_heading'] = "This is not the exact location.";
$_lang['reframebrain.map.location_obfuscated_content'] = "For privacy / security reasons, the marker has been placed randomly within a [[+radius]] km radius.";

// Location
// =====================================================================

$_lang['reframebrain.location.heading'] = "Location";
$_lang['reframebrain.location.elevation'] = "Elevation";

// Address
// =====================================================================

$_lang['reframebrain.address.heading'] = "Address";
