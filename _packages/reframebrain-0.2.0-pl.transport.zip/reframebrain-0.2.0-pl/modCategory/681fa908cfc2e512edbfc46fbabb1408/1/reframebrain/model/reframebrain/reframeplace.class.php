<?php
/**
 * @package ReframeBrain
 */
class reframePlace extends xPDOSimpleObject {}
?>