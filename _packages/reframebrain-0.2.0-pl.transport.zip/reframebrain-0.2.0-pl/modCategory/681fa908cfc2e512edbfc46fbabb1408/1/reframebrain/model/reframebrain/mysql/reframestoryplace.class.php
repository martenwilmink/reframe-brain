<?php
/**
 * @package ReframeBrain
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/reframestoryplace.class.php');
class reframeStoryPlace_mysql extends reframeStoryPlace {}
?>