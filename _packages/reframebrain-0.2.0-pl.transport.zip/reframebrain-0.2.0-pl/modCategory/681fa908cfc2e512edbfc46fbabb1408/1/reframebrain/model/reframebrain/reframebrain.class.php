<?php
/**
 * @package ReframeBrain
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

class ReframeBrain extends \FractalFarming\ReframeBrain\ReframeBrain
{}