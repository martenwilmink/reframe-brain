<?php
/**
 * @package ReframeBrain
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/reframelinkplace.class.php');
class reframeLinkPlace_mysql extends reframeLinkPlace {}
?>