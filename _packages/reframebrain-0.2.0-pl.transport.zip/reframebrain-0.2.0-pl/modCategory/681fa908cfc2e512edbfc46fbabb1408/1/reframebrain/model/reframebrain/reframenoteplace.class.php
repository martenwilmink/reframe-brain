<?php
/**
 * @package ReframeBrain
 */
class reframeNotePlace extends earthNote {}
?>