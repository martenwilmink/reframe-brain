<?php
/**
 * @package ReframeBrain
 */
class reframeImagePlace extends earthImage {}
?>