<?php
$modx->controller->addLexiconTopic('reframebrain:manager');