<?php
/**
 * @package ReframeBrain
 */
class reframeLinkPlace extends earthLink {}
?>