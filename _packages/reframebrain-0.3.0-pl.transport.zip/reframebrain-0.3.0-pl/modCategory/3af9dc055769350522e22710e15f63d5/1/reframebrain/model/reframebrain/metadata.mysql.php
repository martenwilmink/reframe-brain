<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'reframeStory',
    1 => 'reframePlace',
    2 => 'reframeStoryPlace',
  ),
  'earthImage' => 
  array (
    0 => 'reframeImagePlace',
  ),
  'earthLink' => 
  array (
    0 => 'reframeLinkPlace',
  ),
  'earthNote' => 
  array (
    0 => 'reframeNotePlace',
  ),
);