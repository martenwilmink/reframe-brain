<?php
/**
 * @package ReframeBrain
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/reframeimageplace.class.php');
class reframeImagePlace_mysql extends reframeImagePlace {}
?>