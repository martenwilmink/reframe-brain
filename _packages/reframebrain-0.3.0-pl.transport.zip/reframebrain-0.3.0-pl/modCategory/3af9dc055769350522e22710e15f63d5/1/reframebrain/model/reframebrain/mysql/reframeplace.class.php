<?php
/**
 * @package ReframeBrain
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/reframeplace.class.php');
class reframePlace_mysql extends reframePlace {}
?>