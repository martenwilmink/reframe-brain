<?php
/**
 * @package ReframeBrain
 */
class reframeStory extends xPDOSimpleObject {}
?>