<?php
/**
 * @package ReframeBrain
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/reframenoteplace.class.php');
class reframeNotePlace_mysql extends reframeNotePlace {}
?>