<?php
/**
 * @package ReframeBrain
 */
class reframeStoryPlace extends xPDOSimpleObject {}
?>