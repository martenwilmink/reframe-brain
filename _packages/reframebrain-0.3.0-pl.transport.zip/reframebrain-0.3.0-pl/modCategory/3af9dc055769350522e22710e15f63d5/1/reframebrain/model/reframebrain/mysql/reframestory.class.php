<?php
/**
 * @package ReframeBrain
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/reframestory.class.php');
class reframeStory_mysql extends reframeStory {}
?>