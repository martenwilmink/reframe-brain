<?php
$modx->lexicon->load('reframebrain:default');